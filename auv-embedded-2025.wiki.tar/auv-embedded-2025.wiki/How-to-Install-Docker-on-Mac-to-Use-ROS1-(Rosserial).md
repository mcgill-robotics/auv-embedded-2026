1.Download Docker. Go on official website and make sure to select the one that is appropriate to your chip (i.e silicon or intel).

2.Sign in or Sign up (you can also sign up with Google its easier) 

3. Open your terminal (not the one inside the docker, but your laptop's terminal)

4. Check if you downloaded Docker correctly: 
```
ls /Applications/Docker.app
```
If it says Contents (then it is installed correctly)

5.Check the version
```
docker --version
```
If you get version 27.5.1, build 9f9e405 (or something of the sort) then it works 

6. Download Ros Image for Docker (Noetic for Ros1) 
Note: it is not Noetic for Ros2, its Foxy 
Run this command on the terminal: 

```
docker pull ros:noetic-ros-core
```
Then you should see a lot of downloads going on, once you see "Status: Downloaded newer image for ros:noetic-ros-core" then you are good!

7. Create and Run a Container 

Run this command on the terminal: 
```
docker run -it --name ros1_container ros:noetic-ros-core bash
```
This downloads and runs a ROS1 Noetic container.
If successful, your terminal should change to: 
```
root@<container_id>:/#

```
8. Run Roscore 
Run this command on your terminal: 
```
roscore
```
Your expected output should be:
```
started roslaunch server http://<container_id>:40621/
ros_comm version 1.17.0
...
process[master]: started with pid [35]
ROS_MASTER_URI=http://<container_id>:11311/
```

This confirms that the ROS master is running.

UP UNTIL THIS POINT EVERYTHING IS DONE IN THE SAME TERMINAL (LETS CALL IT THE FIRST TERMINAL) 

9. Open a SECOND terminal (still on your computer) and attach to the same container:

Run this command on your terminal: 
```
docker exec -it ros1_container bash
```
You should see:
```
root@<container_id>:/#

```
10. Rostopic List 

Now this step is a bit weird. So run rostopic list on the second terminal, but you are most likely going to get an error here that says "command not found". However, here is a way to tackle it.

First run rostopic list on your terminal: 

```
rostopic list
```
If you get an error, it means the ROS environment isn’t sourced.

Fix it by running:
```
source /opt/ros/noetic/setup.bash
rostopic list

```
After that you should get: 
```
/rosout
/rosout_agg

```
BUT, you want to make this automatic, so run:
```
echo "source /opt/ros/noetic/setup.bash" >> ~/.bashrc
source ~/.bashrc

```
Again you should get: 
```
/rosout
/rosout_agg

```

11. Check Active ROS Topics

Run again:
```
rostopic list
```
You should get:

```
/rosout
/rosout_agg
```

12. Publish & Subscribe to a ROS Topic
Now, let's send and receive messages in ROS.
Publish a Test Message
In your first terminal, run:
```
rostopic pub /test_topic std_msgs/String "data: 'Hello, ROS'" -r 1

```
Note. don't put a "!", its not going to work. 

This publishes "Hello, ROS!" to /test_topic every second.

13. Open a third terminal 
14. Run the container
Run in the terminal:
```
docker exec -it ros1_container bash

```
15. Subscribe to the Topic
Now in your third terminal still. 

Run in the terminal:  
```
rostopic echo /test_topic

```
Then, you are done. You should see on the same terminal data: "Hello, ROS" 

Done


