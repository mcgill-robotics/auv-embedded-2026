# Welcome to the AUV-Embedded-2025 Wiki!

Welcome to the official wiki for the AUV-Embedded-2025 team at McGill Robotics! Here, you'll find information about our team's mission, structure, and the key components we develop. We aim to push the boundaries of underwater robotics by designing advanced PCBs and embedded systems for autonomous navigation and task performance.

## Overview
We are the electrical subteam of the AUV (Autonomous Underwater Vehicle) team at McGill Robotics. Our mission is to design and implement the PCBs and embedded systems that power our underwater robot, enabling it to navigate and perform tasks autonomously. Our team comprises dedicated students with diverse skills in electrical, computer, and software engineering.

## Team Structure

### Electrical Leads
- [John-Paul Chouery](https://www.linkedin.com/in/jchouery/)
- [Andrew Kan](https://www.linkedin.com/in/andrew-kan1/)

### Project Managers
- [Barry Zhang](https://www.linkedin.com/in/brrzhang/) (Electrical Advisor)
- [Celina Belleville](https://www.linkedin.com/in/cbelleville/)

### Senior Members
- [Rafid Saif](https://www.linkedin.com/in/rafid-saif/) (Electrical Advisor)
- [Winnie Pan](https://www.linkedin.com/in/winnie-pan-b454471aa/) (Mechanical Advisor)
- [Anna Joy Aylward Burgess](https://www.linkedin.com/in/anna-joy-aylward-burgess-38362b198/)
- [Sam Faubert](https://www.linkedin.com/in/samuel-faubert/)
- [Celine Shao](https://www.linkedin.com/in/c%C3%A9line-shao-3700a1256/)
- [Farah Mehzabeen](https://www.linkedin.com/in/farah-mehzabeen/)
- [Yuheng Liu](https://www.linkedin.com/in/yuheng-liu-464095266/)
- Nathan Savard

## Main PCBs

Our AUV incorporates five main PCBs, each serving a critical function:

- **Actuator board**: Controls the robot's grabber, dropper, and torpedo.
- **Display board**: Powers the pressure sensor and displays critical data.
- **Power board**: Manages power distribution to various components and the thrusters.
- **Pressure sensor board**: Monitors underwater pressure to calculate depth underwater.
- **Hydrophone board**: Detects and processes acoustic signals for positioning.

All boards, except for the hydrophone board, use the Teensy 4.0 microcontroller and are powered by the Arduino framework. The folder structure is organized using PlatformIO. The hydrophone board utilizes an STM32 microcontroller for enhanced processing capabilities.

## Anonymouse Disclosure Form

If you would like to send something anonymously to the electrical leads, you can do so through the [AUV Electrical Anonymous Disclosure Form](https://forms.gle/qo5vXNf3iWWJUFg2A).