## Prerequisites

Before proceeding, ensure you have completed **Step 8** of the "Installing ROS Noetic on WSL with Ubuntu 20.04" tutorial. You must have all the required packages installed and ROS properly configured.

Your **MCU should be running rosserial code**, and this tutorial will teach you how to test it. Think of your **WSL setup as a simulation of the Jetson running ROS 1**.


## Running the Propulsion Package (Thruster Dry Test)

This section explains how to **bind the power board Teensy to WSL** and **run a dry test** for the thrusters.

1. Open an **elevated Command Prompt** (`cmd` as administrator) and type:
   ```bash
   usbipd list
   ```
Identify the device (in this case, the power board Teensy).

2. Bind the device using its busid:
   ```bash
   usbipd bind --busid <busid>
   ```

   Then attach your device:
   ```bash
   usbipd attach --wsl --busid <busid>

3. Open WSL and check if the Teensy is recognized:
   ```bash
   ls /dev/tty*
   ```
   Let us assume it is connected to `/dev/ttyACM0`.

4. Clone the software repository:
   ```bash
   git clone https://github.com/mcgill-robotics/auv-2025
   ```

5. Modify the propulsion launch file:
   ```bash
   vim auv-2025/catkin_ws/src/propulsion/launch/propulsion.launch
   ```
   - Press `i` to edit.
   - Locate the line `<param name="port" value="/dev/power"/>`
   - Change `/dev/power/` to the correct port, e.g.: `<param name="port" value="/dev/ttyACM0"/>`
   - Press `Escape` and type `:wq` and click on `Enter` to save and exit.
   - If you have issues exiting Vim, you're not alone, google it.

6. Build the workspace:
   ```bash
   cd auv-2025/catkin_ws
   catkin build
   ```
   Ensure that propulsion and auv_msgs packages build successfully.

7. Source the worksapce:
   ```bash
   source devel/setup.bash
   ```

8. Launch the dry test:
   ```bash
   roslaunch propulsion drytest.launch
   ```

   If connected to the power board Teensy, follow the menu instructions to test each thruster one by one.
   
   ⚠ Avoid running all thrusters simultaneously due to capacitance limitations that need to be resolved.


## Testing an MCU Running rosserial

If the MCU you want to test includes any custom messages, you will have to proceed by building and sourcing just like in the propulsion example instead of simply running `roscore`. The process is much more complicated, and I recommend to avoid custom messages where possible.

To test an MCU running rosserial, follow these steps:

1. Start a `tmux` session:
   ```bash
   tmux
   ```
   This allows you to split the terminal. You could use multiple terminals instead, but `tmux` makes navigation easier.

2. Start `roscore`:
   ```bash
   roscore
   ```

3. Split the terminal:
   - Press `Ctrl + b`, then `"` to split horizontally.
   - Press `Ctrl + b`, then `%` to split vertically.
   - Navigate between panes using `Ctrl + b` and the arrow keys.

4. Run the rosserial node:
   Assuming the device is already bound to WSL and is on /dev/ttyUSB0, start the serial node:
   ```bash
   rosrun rosserial_python serial_node.py _port:=/dev/ttyUSB0 _baud:=115200
   ```

5. Check available topics:
   In another `tmux` pane, run:
   ```bash
   rostopic list
   ```

6. Listen to a topic:
   Chose a topic and echo its message:
   ```bash
   rostopic echo /topic_name
   ```

7. Publishing to a topic:
   - Example: Publishing thruster PWM signals:
      ```bash
      rostopic pub /propulsion/microseconds auv_msgs/ThrusterMicroseconds "{microseconds: [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500]}"
      ```
   - Simpler example: Publishing an integer value of 1 at 10 Hz:
      ```bash
      rostopic pub /example_topic std_msgs/Int32 1 -r 10
      ```

Now your MCU is communicating with ROS!