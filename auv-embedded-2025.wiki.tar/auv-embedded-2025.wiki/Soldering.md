**Here's a couple good videos for reference on how to solder:**
* [How to Solder + Soldering Through-hole Components](https://youtu.be/PXFBqa_HyIQ?si=GxfswPWothrGgnzv) -> good first intro
* [How to Solder + Soldering SMD Components](https://youtu.be/fYInlAmPnGo?si=2W9KEWNk6kYF6MNG) -> long and thorough, skip around to find parts you care about

`smd = surface mount device`